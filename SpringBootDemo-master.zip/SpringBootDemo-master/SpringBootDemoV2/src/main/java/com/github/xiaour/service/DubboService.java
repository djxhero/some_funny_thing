package com.github.xiaour.service;

/**
 * @Author: Xiaour
 * @Description:
 * @Date: 2018/4/25 16:57
 */

public interface DubboService {

     String hello(String name);


}
